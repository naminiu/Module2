package vn.ltt.shop.view;

public enum InputOption {
    ADD, UPDATE, SHOW, DELETE, FIND, STATISTICAL, SORT
}
