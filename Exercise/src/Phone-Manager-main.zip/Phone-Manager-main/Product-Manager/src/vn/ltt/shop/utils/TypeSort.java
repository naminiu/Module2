package vn.ltt.shop.utils;

public enum TypeSort {
    ASC, DESC
}
