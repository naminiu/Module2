import vn.ltt.shop.model.Role;
import vn.ltt.shop.view.MainLauncher;

public class MainMember {
    public static void main(String[] args) {
        MainLauncher.mainLauncher(Role.USER);
    }
}
