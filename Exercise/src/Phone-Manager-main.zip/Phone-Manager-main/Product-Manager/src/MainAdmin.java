import vn.ltt.shop.model.Role;
import vn.ltt.shop.view.MainLauncher;


public class MainAdmin {
    public static void main(String[] args) {
        MainLauncher.mainLauncher(Role.ADMIN);
    }
}